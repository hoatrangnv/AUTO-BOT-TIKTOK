




                              <div class="col-xl-4" onclick="action('bot_tha_tym')">

                                <div class="media widget-media p-4 bg-white border" style="cursor: pointer;">
                                  <div class="icon rounded-circle mr-4 bg-primary">
                                    <i class="mdi mdi-account-heart text-white "></i>
                                  </div>
                                  <div class="media-body align-self-center">
                                    <h3 class="text-primary mb-2">Bot Thả Tim</h3>
                                    <p style="color: green;">Hoạt Động</p>
                                  </div>
                                </div>
                             
                              </div>


                              <div class="col-xl-4" onclick="action('bot_comment')">
                          
                                <div class="media widget-media p-4 bg-white border" style="cursor: pointer;">
                                  <div class="icon rounded-circle bg-warning mr-4">
                                    <i class="mdi mdi-comment-processing-outline text-white "></i>
                                  </div>
                                  <div class="media-body align-self-center">
                                    <h3 class="text-primary mb-2">Bot Comment</h3>
                                    <p style="color: green;">Hoạt Động</p>
                                  </div>
                                </div>

                              </div>


                              <div class="col-xl-4" onclick="action('bot_follow')">
 
                                <div class="media widget-media p-4 bg-white border" style="cursor: pointer;">
                                  <div class="icon rounded-circle mr-4 bg-danger">
                                    <i class="mdi mdi-account-multiple-plus-outline text-white "></i>
                                  </div>
                                  <div class="media-body align-self-center">
                                    <h3 class="text-primary mb-2">Bot Follow</h3>
                                    <p style="color: green;">Hoạt Động</p>
                                  </div>
                                </div>

                              </div>







                              <div class="col-xl-4" onclick="action('auto_heart')">

                                <div class="media widget-media p-4 bg-white border" style="cursor: pointer;">
                                  <div class="icon rounded-circle mr-4 bg-primary">
                                    <i class="mdi mdi-account-heart text-white "></i>
                                  </div>
                                  <div class="media-body align-self-center">
                                    <h3 class="text-primary mb-2">Auto Thả Tim</h3>
                                    <p style="color: green;">Đang Cập Nhật</p>
                                  </div>
                                </div>
                 
                              </div>


                              <div class="col-xl-4" onclick="action('auto_comment')">
                            
                                <div class="media widget-media p-4 bg-white border" style="cursor: pointer;">
                                  <div class="icon rounded-circle bg-warning mr-4">
                                    <i class="mdi mdi-comment-processing-outline text-white "></i>
                                  </div>
                                  <div class="media-body align-self-center">
                                    <h3 class="text-primary mb-2">Auto Comment</h3>
                                    <p style="color: green;">đang thử nghiệm</p>
                                  </div>
                                </div>

                              </div>


                              <div class="col-xl-4" onclick="action('auto_follow')">

                                <div class="media widget-media p-4 bg-white border" style="cursor: pointer;">
                                  <div class="icon rounded-circle mr-4 bg-danger">
                                    <i class="mdi mdi-account-multiple-plus-outline text-white "></i>
                                  </div>
                                  <div class="media-body align-self-center">
                                    <h3 class="text-primary mb-2">Auto Follow</h3>
                                    <p style="color: green;">Đang Test</p>
                                  </div>
                                </div>

                              </div>







                              <div class="col-xl-4" onclick="javascript:void(toastr['info']('Cooming Soon!', 'Bảo Trì!'))">

                                <div class="media widget-media p-4 bg-white border" style="cursor: pointer;">
                                  <div class="icon rounded-circle mr-4 bg-primary">
                                    <i class="mdi mdi-account-heart text-white "></i>
                                  </div>
                                  <div class="media-body align-self-center">
                                    <h3 class="text-primary mb-2">Vip Thả Tim</h3>
                                    <p style="color: red;">Bảo Trì</p>
                                  </div>
                                </div>
          
                              </div>


                              <div class="col-xl-4" onclick="javascript:void(toastr['info']('Cooming Soon!', 'Bảo Trì!'))">
                       
                                <div class="media widget-media p-4 bg-white border" style="cursor: pointer;">
                                  <div class="icon rounded-circle bg-warning mr-4">
                                    <i class="mdi mdi-comment-processing-outline text-white "></i>
                                  </div>
                                  <div class="media-body align-self-center">
                                    <h3 class="text-primary mb-2">Vip Comment</h3>
                                    <p style="color: red;">Bảo Trì</p>
                                  </div>
                                </div>

                              </div>


                              <div class="col-xl-4" onclick="javascript:void(toastr['info']('Cooming Soon!', 'Bảo Trì!'))">

                                <div class="media widget-media p-4 bg-white border" style="cursor: pointer;">
                                  <div class="icon rounded-circle mr-4 bg-danger">
                                    <i class="mdi mdi-account-multiple-plus-outline text-white "></i>
                                  </div>
                                  <div class="media-body align-self-center">
                                    <h3 class="text-primary mb-2">Vip Follow</h3>
                                    <p style="color: red;">Bảo Trì</p>
                                  </div>
                                </div>

                              </div>







